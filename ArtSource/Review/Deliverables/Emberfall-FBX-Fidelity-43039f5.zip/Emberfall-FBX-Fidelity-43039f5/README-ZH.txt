这是 FBX 精度审阅包，不是游戏工程或 APK。
Source/ 只包含复现必需的原始 .blend、最终 FBX、导出助手和两张原纹理；Evidence/ 是原始测量、拒绝实验、日志及全量回归记录。
最终 FBX 位于 Source/Assets/Resources/BlenderPilot/Vanguard.fbx，SHA256应为0dac3643c78b839a2d42ceee5b605f6e71f91a6addf4c9631a63c62372e5219c。

安装具备可用 Blender 4.3.2 的环境后，可在解压后的目录执行：
python3 Evidence/Portable-Reproduction/reproduce.py --source-root Source --evidence-root Evidence --output /tmp/Emberfall-Fidelity-Repro --blender blender
输出目录必须事先不存在，且位于解压目录之外。脚本不修改源文件或归档。复现会再次保留基线FAIL/候选PASS；二进制文件可因导出时间等信息不同而有不同哈希，检查的是曲线和受检静态数据一致性，不保证字节确定性。

0.1毫米阈值未放宽。4923个离散样本不构成连续时间数学证明，也不证明Unity导入后精度、实际帧率或游戏手感。试点保持默认关闭。完整游戏工程通过独立源码附件交付。
